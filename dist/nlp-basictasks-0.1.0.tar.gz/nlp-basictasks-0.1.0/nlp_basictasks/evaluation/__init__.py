from .clsEvaluator import clsEvaluator
from .pairclsEvaluator import pairclsEvaluator
from .nerEvaluator import nerEvaluator
from .stsEvaluator import stsEvaluator
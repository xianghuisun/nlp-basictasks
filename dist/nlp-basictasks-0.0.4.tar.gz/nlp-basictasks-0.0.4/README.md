# nlp-basictasks
A simple framework for building some basic NLP tasks


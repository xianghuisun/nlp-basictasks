# nlp-basictasks

## 安装
```bash
pip install --index-url https://pypi.org/project/ nlp-basictasks==0.1.4
```


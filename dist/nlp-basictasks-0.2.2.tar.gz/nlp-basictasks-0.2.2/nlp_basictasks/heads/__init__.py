from .cls import ClsHead
from .ner import NerHead
from .sts import SoftmaxLossHead
from .mrc import MrcHead
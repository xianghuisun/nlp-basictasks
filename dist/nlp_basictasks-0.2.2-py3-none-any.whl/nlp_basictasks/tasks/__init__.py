from .cls import cls
from .ner import Ner
from .sts import sts
from .mrc import mrc